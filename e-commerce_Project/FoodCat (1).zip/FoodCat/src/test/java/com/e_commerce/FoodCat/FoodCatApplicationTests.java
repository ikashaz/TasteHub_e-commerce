package com.e_commerce.FoodCat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodCatApplicationTests {

	@Test
	void contextLoads() {
	}

}
